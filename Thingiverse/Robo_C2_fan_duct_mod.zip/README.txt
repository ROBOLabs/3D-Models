                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2622310
Robo C2 fan duct mod by ROBO3D is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This is a mod for a single extruder on a Robo C2 (also work for a Robo R2) for better airflow to cool your 3d printed parts, directing airflow a little bit better than the stock fan duct, all using the existing fan duct hardware. A full tutorial on how to install this is in the link below:

https://help.robo3d.com/hc/en-us/articles/115002540172 

# Print Settings

Printer Brand: Robo 3D
Printer: C2 R2
Rafts: Doesn't Matter
Supports: Yes
Resolution: .2
Infill: 40%

Notes: 
Make sure you print with supports. If printing on a Robo C2 bed, you must rotate the object 45 degrees in order for it to fit on the build plate. Full install instructions are here:

https://help.robo3d.com/hc/en-us/articles/115002540172